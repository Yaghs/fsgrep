/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   fsgrep.h
 * Author: student
 *
 * Created on September 26, 2023, 10:46 PM
 */

#ifndef FSGREP_H
#define FSGREP_H

#ifdef __cplusplus
extern "C" {
#endif
    void fsgrep();



#ifdef __cplusplus
}
#endif

#endif /* FSGREP_H */

